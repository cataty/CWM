import supabase from "./supabase";
import { addUserProfile, getUserProfileById } from "./user-profile";

let user = {
    id: null,
    email: null,
};

let observers = [];


/**
 * Carga el perfil del usuario actual y lo agrega al estado global del usuario mediante updateUser.
 *
 * @returns {Promise<void>} Una promesa que se resuelve cuando el perfil ha sido cargado y actualizado.
 */
loadCurrentUser(); // Invoca la carga del usuario actual inmediatamente.

async function loadCurrentUser() {
    const { data } = await supabase.auth.getUser();
    if(!data?.user) return null;

    updateUser({
        id: data.user.id,
        email: data.user.email,
    });

    loadCurrentUserProfile();
}

async function loadCurrentUserProfile() { //carga los datos del perfil y los agrega al usuario mediante updateUser
    try {
        const profile = await getUserProfileById(user.id);
        updateUser({
            ...profile,
        })
    } catch (error) {
        console.error('[auth.js register] No se pudo cargar el perfil del usuario: ', error);

        throw new Error('No se pudo cargar el perfil del usuario:' + error + email + password);
    }

}

/**
 * 
 * @param {{id: string|null, email: string|null}} data 
 */

function updateUser(data) {
    user = {
        ...user,
        ...data,
    };
    notifyAll();
}

/**
 * Registra un usuario nuevo
 * 
 * @param {string} email 
 * @param {string} password 
 * @returns {Promise}
 */
export async function register(email, password, nickname) {
    const { data, error } = await supabase.auth.signUp({
        email,
        password,
    });

    if (error) {
        console.error('[auth.js register] No se pudo registrar el usuario: ', error);

        throw new Error('No se pudo registrar el usuario:' + error + email + password);
    }

    try {
        await addUserProfile({
            email: data.user.email,
            id: data.user.id,
            display_name: nickname
        })
    } catch (error){
            console.error('[auth.js register] No se pudo crear el perfil del usuario: ', error);

        throw new Error('No se pudo crear el perfil del usuario:' + error + email + password);
    }

    updateUser({
        email: data.user.email,
        id: data.user.id
    })

    console.log('[auth.js register] Usuario registrado: ', user);

    return data.user;

}

/**
 * Autentica al usuario.
 *
 * @param {string} email - El email del usuario.
 * @param {string} password - La contraseña del usuario.
 * @returns {Promise<Object>} El usuario autenticado
 */
export async function login(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
    });

    if (error) {
        console.error('[auth.js login] No se pudo iniciar sesion: ', error);

        throw new Error('No se pudo iniciar sesion:' + error);
    }

    updateUser({
        email: data.user.email,
        id: data.user.id
    })

     loadCurrentUserProfile();

     console.log(data.user);

    return data.user;
}

/**
 * Termina la sesión del usuario.
 *
 * @returns {Promise<void>} Una promesa que se resuelve cuando la sesión ha terminado.
 */

export async function logout() {
    supabase.auth.signOut();

    updateUser({
        email: null,
        id: null
    })
}

// Observers
/**
 * 
 * @param {*} callback 
 */
export async function subscribeToAuth(callback) {
    console.log('notifyObservers llamado con user:', user);
    observers.push(callback);
    notifyObservers(callback);
}

/**
 * 
 * @param {({id: string|null, email: string|null}) => void} callback 
 */

function notifyObservers(callback) {
    callback({ ...user })
}

function notifyAll() {
    observers.forEach(callback => notifyObservers(callback));
}