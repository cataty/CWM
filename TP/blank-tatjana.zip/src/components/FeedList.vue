<script>
import FeedForm from './FeedForm.vue';
import { getUserProfileById } from '../services/user-profile';
import { fetchPostComments } from '../services/feed';

export default {
    name: "FeedList",
    components: { FeedForm },
    data() {
        return {
            postList: [],
            loading: false,
        }
    },
    props: {
        user: { type: Object, required: true },
        posts: { type: Array, required: true },
    },
    methods: {
        scrollToBottom() {
            const feedContainer = this.$refs.feedContainer;
            feedContainer.scrollTop = feedContainer.scrollHeight;
        },
        async enrichPosts(posts) {
            this.loading = true;
            this.postList = posts.map(post => ({ ...post }));
            for (const post of this.postList) {
                try {
                    post.profile = await getUserProfileById(post.user_id);
                } catch (error) {
                    post.profile = { display_name: null };
                }
                try {
                    post.comments = await fetchPostComments(post.id);
                    for (const comment of post.comments) {
                        try {
                            comment.profile = await getUserProfileById(comment.user_id);
                        } catch (error) {
                            comment.profile = { display_name: null };
                        }
                    }
                } catch (error) {
                    post.comments = [];
                }
            }
            this.loading = false;
        }
    },
    watch: {
        posts: {
            handler(newPosts) {
                this.enrichPosts(newPosts);
            },
            immediate: true,
            deep: true
        }
    }
}
</script>

<template>
    <div v-if="!loading">
        <h2 class="sr-only"> Lista de Posteos </h2>
        <div class="max-h-[calc(100vh-400px)] lg:max-h-[calc(100vh-340px)] overflow-scroll p-4" ref="feedContainer">
            <div v-for="post in postList" :key="post.id"
                class="flex flex-col gap-2 mb-4 border border-indigo-300 bg-slate-100 rounded p-4 shadow-md basis-full">
                <p class="text-xs text-indigo-900 flex justify-between"><span class="font-bold">{{
                    post.profile?.display_name || ("usuario " + post.user_id) }}
                    </span><span>{{ post.created_at ? post.created_at.replace('T', ' ').substring(0, 19) : '' }}</span>
                </p>
                <p class="p-4 bg-white">{{ post.content }}</p>
                <router-link :to="`/post/${post.id}`" class="text-sm font-bold text-indigo-600">ver
                    comentarios</router-link>
                <!-- 
                <button class="accordion">Comentarios</button>
                <div class="panel flex justify-center visible">
    
<div v-for="comment in post.comments" class="flex flex-col gap-2 mb-4 border border-indigo-300 rounded p-4 shadow-md"
                :key="comment.id">
                <div class="text-sm text-indigo-700 flex justify-between"><span class="font-bold">{{ comment.profile?.display_name || ("usuario " + comment.user_id) }}
                    </span> <span>{{ post.created_at }}</span></div>
                <div class="py-4">{{ post.content }}</div> 
                </div>
                    
                    <FeedForm :user="user" @post-submitted="$emit('comment-submitted', $event)"> Publicar Comentario
                    </FeedForm>
                </div> -->
            </div>
        </div>
    </div>

    <div v-else>
        <p class="font-bold text-indigo-700 mx-auto">cargando...</p>
    </div>
</template>