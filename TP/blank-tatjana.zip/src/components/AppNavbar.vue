<script>
import { subscribeToAuth } from '../services/auth';
import { getUserProfileById } from '../services/user-profile';

export default {
    name: 'AppNavbar',
    data: function () {
        return {
            user: {
                id: null,
                email: null
            },
        }
    },
    props: {
        email: {
            type: String,
            default: null,
        },
        id: {
            type: String,
            default: null,
        },
    },
    methods: {
        handleLogout() {
            this.$emit('user-logged-out');
        },
    },
    async mounted() {
        subscribeToAuth(async userData => {
            if (!userData.id) {
                console.warn('userData.id is missing!');
            }
            this.user.id = userData.id;
            this.user.email = userData.email;

            try {
                const profileData = await getUserProfileById(this.user.id);
                this.user = profileData;
            } catch (error) {
                console.error("Error trayendo los datos de perfil:", error);
            }
        });
    }
}
</script>

<template>
    
<!-- navbar goes here -->
<nav class="bg-indigo-700 h-16">
  <div class="max-w-6xl mx-auto px-4">
    <div class="flex justify-between">


      <div class="flex space-x-4 h-16">
    <!-- 
        <div>
          <a href="#" class="flex items-center py-5 px-2 rounded-full">
            <img src="../../public/img/favicon.svg" alt="">
            <span class="font-bold">Mundofertas</span>
          </a>
        </div> -->

        <div class="hidden md:flex items-center space-x-1">
         <ul class="navbar-list">
            <li><router-link to="/" class="text-white px-4">Home</router-link></li>
            <template v-if="id === null">
                <li>
                    <router-link to="/login" class="text-white px-4">Iniciar sesión</router-link>
                </li>
                <li>
                    <router-link to="/registro" class="text-white px-4">Registrarse</router-link>
                </li>
            </template>
            <template v-else>
                <li>
                    <router-link to="/feed" class="text-white px-4">Feed de ofertas</router-link>
                </li>
                <li>
                    <router-link to="/perfil" class="text-white px-4">Mi perfil</router-link>
                </li>
                <li>
                    <form action="#" @submit.prevent="handleLogout">
                        <button type="submit" class="text-white px-4">{{ user.display_name ? user.display_name : email }} (Cerrar sesión)</button>
                    </form>
                </li>
            </template>
        </ul>
        </div>
      </div>

      <div class="md:hidden flex items-center">
        <button class="mobile-menu-button">
          <svg class="w-6 h-6" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
      </div>

    </div>
  </div>

  <div class="mobile-menu hidden md:hidden bg-indigo-700">
        <ul class="navbar-list">
            <li><router-link to="/" class="text-white px-4">Home</router-link></li>
            <template v-if="id === null">
                <li>
                    <router-link to="/login" class="text-white px-4">Iniciar sesión</router-link>
                </li>
                <li>
                    <router-link to="/registro" class="text-white px-4">Registrarse</router-link>
                </li>
            </template>
            <template v-else>
                <li>
                    <router-link to="/feed" class="text-white px-4">Feed de ofertas</router-link>
                </li>
                <li>
                    <router-link to="/perfil" class="text-white px-4">Mi perfil</router-link>
                </li>
                <li>
                    <form action="#" @submit.prevent="handleLogout">
                        <button type="submit" class="text-white px-4">{{ user.display_name ? user.display_name : email }} (Cerrar sesión)</button>
                    </form>
                </li>
            </template>
        </ul>
  </div>
</nav>

</template>