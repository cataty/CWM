<script>
export default {
    name: 'AppFooter',
}
</script>

<template>
    <footer class="text-white flex justify-center items-center align-center bg-indigo-900 p-4 h-25">
        <p>da Vinci &copy; 2025</p>
    </footer>
</template>