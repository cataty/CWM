<script>
import { subscribeToAuth } from '../services/auth';

export default {
    name: "FeedForm",
    props: {
        user: {
            type: Object,
            required: true
        }
    },
    data() {
        return {
            newPost: {
                user_id: "",
                content: "",
                price: "",
                address: "",
                date: new Date().toLocaleString()
            },
            routeParams: {},
        }
    },
    methods: {
        handleSubmit() {
            if (!this.user || !this.user.id) {
                console.error('User is not defined!');
                return;
            }
            console.log(this.user, this.newPost)
            this.$emit('post-submitted', {
                content: this.newPost.content,
                price: this.newPost.price,
                address: this.newPost.address,
                created_at: this.newPost.date,
                user_id: this.user.id // asegurar que sea un string
            });
            this.newPost.content = '';
        }
    },
    emits: {
        'post-submitted': function (payload) {
            return typeof payload.content === 'string' &&
                payload.content.trim().length > 0 &&
                typeof payload.created_at === 'string' &&
                typeof payload.price === 'string' &&
                payload.price.trim().length > 0 &&
                payload.price.trim().length > 10 &&
                typeof payload.address === 'string' &&
                payload.price.trim().length > 0 &&
                typeof payload.user_id === 'string' &&
                payload.user_id.trim().length > 0;
        }
    },
    mounted() {
        const routeParams = this.$route.params;
        this.routeParams = routeParams;
        console.log(routeParams);
    }
}


</script>

<template>
    <form action="#" @submit.prevent="handleSubmit()" class="max-w-160 mt-4">
        <div class="mb-4">
            <label for="text" class="block mb-2 text-indigo-700 font-bold">
                <slot />
            </label>
            <textarea type="text" id="text" class="border border-indigo-900 rounded py-2 px-4 w-full"
                v-model="newPost.content"></textarea>
        </div>
        <template v-if="!routeParams.id">
            <div class="mb-4">
                <label for="address" class="block mb-2 text-indigo-700 font-bold">Precio</label>
                <input type="text" id="address" class="border border-indigo-900 rounded py-2 px-4 w-full">
            </div>
            <div class="mb-4">
                <label for="address" class="block mb-2 text-indigo-700 font-bold">Dirección del supermercado</label>
                <input type="text" id="address" class="border border-indigo-900 rounded py-2 px-4 w-full">
            </div>

        </template>
        <button type="submit" class="py-2 px-4 rounded bg-indigo-500 text-white">
            Enviar
        </button>
    </form>
</template>