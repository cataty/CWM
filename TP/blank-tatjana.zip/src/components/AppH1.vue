<script>
export default{
    name: 'AppH1',
    components: 'slot'
}
</script>

<template>
    <h1 
        class= "text-5xl text-indigo-900 font-bold mb-8 mx-auto text-center"
    >
<slot />
    </h1>
</template>