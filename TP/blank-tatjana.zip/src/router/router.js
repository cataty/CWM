import { createRouter, createWebHashHistory } from "vue-router";
import Home from '../pages/Home.vue';
import Feed from '../pages/Feed.vue';
import Deal from "../pages/Deal.vue";
import Login from '../pages/Login.vue';
import Register from '../pages/Register.vue';
import UserProfile from '../pages/UserProfile.vue';
import UserProfileEdit from '../pages/UserProfileEdit.vue';
import { subscribeToAuth } from "../services/auth";

const routes = [
    { path: '/', component: Home },
    { path: '/login', component: Login },
    { path: '/registro', component: Register },
    { path: '/feed', component: Feed, meta: { requiresAuth: true, }, },
    { path: '/perfil/editar', component: UserProfileEdit, meta: { requiresAuth: true, }, },
    { path: '/perfil', component: UserProfile, meta: { requiresAuth: true, }, },
    { path: '/post/:id', component: Deal, meta: { requiresAuth: true, }, },
]

const router = createRouter({
    routes,
    history: createWebHashHistory(),
});

let user = {
    id: null,
    email: null
}

subscribeToAuth(userData => user = userData);

router.beforeEach((to,from) => { // from = data de la ruta de la que viene el request, to = data de la ruta nueva
    if(to.meta.requiresAuth && user.id === null){
        return "/login";
    }
})

export default router;
