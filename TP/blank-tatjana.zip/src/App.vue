<script>
import supabase from './services/supabase';
import Home from './pages/Home.vue';
import AppFooter from './components/AppFooter.vue';
import AppNavbar from './components/AppNavbar.vue';
import { subscribeToAuth, logout } from './services/auth';

export default {
    name: 'App',
    components: {
        Home,
        AppFooter,
        AppNavbar,
    },
    data: function () {
        return {
            user: {
                id: null,
                email: null,
            },
        };
    },
    methods: {
/*         handleLogin(userData) {
            console.log("UD ", userData);
            this.user.id = userData.id;
            this.user.email = userData.email;
        }, */
        handleLogout() {
/*             this.user.id = null;
            this.user.email = null;
            this.$emit('user-logged-out'); */
            logout();
            this.$router.push('/login');
        }
    },
    async mounted() {
/*         const {data} = await supabase.auth.getUser();
        this.user.id = data?.user?.id;
        this.user.email = data?.user?.email;
        console.log("user ", this.user); */
        subscribeToAuth(userData => this.user = userData);
        console.log("user ", this.user);
    }
}
</script>

<template>
    <AppNavbar :id="user.id" :email="user.email" ref="navbar" @user-logged-out="handleLogout" />
    <main class="w-full my-12 lg:h-[calc(100vh-260px)] mx-auto">
        <!--router-view @user-logged-in="handleLogin" /> // escucha el evento emitido por el componente Login -->
        <router-view />
    </main>
    <AppFooter />
</template>