<script>
import AppH1 from '../components/AppH1.vue';
import AppFeed from '../components/AppFeed.vue';

export default{
    name: 'Feed',
    components: {
        AppH1,
        AppFeed,
        
    },
    data(){
        return{
newMessage:{
    "email" : "user",
    "content" : ""
},

        }
    },
    methods: {
        sendMessage(){
            this.posts.push({
                email : "user",
                content : this.newMessage.content
            });
            this.newMessage.content="";
        }
    }
}
</script>

<template>
    <AppH1> Feed de ofertas </AppH1>
    <AppFeed />
</template>