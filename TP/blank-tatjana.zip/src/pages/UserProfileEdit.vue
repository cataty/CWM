<script>
import { updateUserProfile, getUserProfileById } from '../services/user-profile'
import { subscribeToAuth } from '../services/auth';

import AppH1 from '../components/AppH1.vue';

export default {
    name: 'EditUserProfile',
    components: { AppH1 },
    data: function () {
        return {
            user: {
                id: null,
                email: null,
            },
            profile: {
                display_name: '',
                neighbourhood: '',
                bio: ''
            },
            updating: false,
        }
    },
    methods: {
        async handleSubmit() {
            try {
                console.log(this.user.id, this.profile)
                this.updating = true;
                await updateUserProfile(this.user.id, {
                    ...this.profile
                });

                this.$router.push('/perfil');

            } catch (error) {
                console.error("Error actualizando los datos del usuario:", error);
            }

        },
        /*         emits: {
                    'user-updated': function (payload) {
                        return typeof payload.email === 'string' &&
                            payload.email.trim().length > 0 &&
                            typeof payload.password === 'string' &&
                            payload.password.trim().length > 0;
                    } */
    },
    mounted() {
        subscribeToAuth(async userData => {
            console.log('userData from subscribeToAuth:', userData);
            if (!userData.id) {
                console.warn('userData.id is missing!');
            }
            this.user.id = userData.id;
            this.user.email = userData.email;

            try {
                const profileData = await getUserProfileById(this.user.id);
                console.log(profileData);
                this.profile = profileData;
            } catch (error) {
                console.error("Error trayendo los datos de perfil:", error);
            }
        });

    }
}

</script>
<template>
    <AppH1>
        Editar mis datos
    </AppH1>

    <div
        class="flex flex-wrap justify-center align-center mt-4 p-12 shadow-md border border-indigo-500 max-w-100 mx-auto">
        <form action="#" @submit.prevent="handleSubmit()" class="flex flex-wrap justify-center">
            <div class="mb-4 basis-full flex justify-center flex-wrap">
                <label for="text" class="block mb-2 mx-auto basis-full text-center">Nombre</label>
                <input type="text" id="name" class="border rounded py-2 px-4 mx-auto" v-model="profile.display_name"
                    value=''></input>
            </div>
            <div class="mb-4 basis-full flex justify-center flex-wrap">
                <label for="text" class="block mb-2 mx-auto basis-full text-center">Email</label>
                <input type="email" id="email" class="border rounded py-2 px-4 mx-auto" v-model="user.email"></input>
            </div>
            <div class="mb-4 basis-full flex justify-center flex-wrap">
                <label for="neighbourhood" class="block mb-2 mx-auto basis-full text-center">Barrio</label>
                <input type="text" id="neighbourhood" class="border rounded py-2 px-4 mx-auto"
                    v-model="profile.neighbourhood" value=''></input>
            </div>
            <div class="mb-4 basis-full flex justify-center flex-wrap">
                <label for="bio" class="block mb-2 mx-auto basis-full text-center">Acerca de mí</label>
                <input type="textarea" id="bio" class="border rounded py-2 px-4 mx-auto" v-model="profile.bio"></input>
            </div>
            <button type="submit" class="rounded-full py-2 px-4 rounded bg-indigo-500 text-white">
                Actualizar
            </button>
        </form>

    </div>
</template>