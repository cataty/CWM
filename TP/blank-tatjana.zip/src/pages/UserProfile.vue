<script>
import AppH1 from '../components/AppH1.vue';
import FeedList from '../components/FeedList.vue';
import { subscribeToAuth } from '../services/auth';
import { fetchPostsByUserId } from '../services/feed';
import { getUserProfileById } from '../services/user-profile';

export default {
    name: 'UserProfile',
    components: { AppH1, FeedList },
    data: function () {
        return {
            user: {
                id: null,
                email: null,
                display_name: '',
                neighbourhood: '',
                bio: ''
            },
            posts: [],
            loading: false,
        }
    },
    methods: {
        async resolveNames() {
            for (const post of this.posts) {
                try {
                    // usar post.user_id o post.user.id dependiendo de cómo están formateados los datos
                    const profileData = await getUserProfileById(post.user_id || post.user.id);
                    post.profile = profileData; // Attach profile data to the post
                } catch (error) {
                    console.error("Error trayendo los datos de perfil:", error);
                }
            }
        }
    },
    async mounted() {
        subscribeToAuth(async userData => {
            this.loading = true;
            
            this.user.id = userData.id;
            this.user.email = userData.email;

            try {
                const profileData = await getUserProfileById(this.user.id);
                console.log(profileData);
                this.user = profileData;
            } catch (error) {
                console.error("Error trayendo los datos de perfil:", error);
            }

            try {
                const posts = await fetchPostsByUserId(this.user.id);
                this.posts = posts;
            } catch (error) {
                console.error("Error trayendo los posteos:", error);
            }
            
            this.loading = false;

        });

    }
}
</script>
<template>
    <AppH1>
        Mi Perfil
    </AppH1>


    <section
        class="flex flex-wrap justify-center align-center m-4 p-12 shadow-md border border-indigo-500 max-w-140 mx-auto">
        <div v-if="!loading">
        <p class="basis-full mb-4"><span class="font-bold text-indigo-700">Nombre: </span>{{ user.display_name ||
            'usuario anonimo' }} </p>
        <p class="basis-full mb-4"><span class="font-bold text-indigo-700">Email: </span>{{ user.email }} </p>
        <p class="basis-full mb-4"><span class="font-bold text-indigo-700">Barrio: </span>{{ user.neighbourhood ||
            'no especificado' }} </p>
        <p class="basis-full mb-4"><span class="font-bold text-indigo-700">Acerca de mí: </span>{{ user.bio }}</p>
        </div>
        <div v-else>
            <p class="font-bold text-indigo-700"> cargando...</p>
        </div>
        <p class="text-indigo-500 mt-8">Querés actualizar tus datos? <router-link to="perfil/editar/"
                class="text-indigo-700">Editar Perfil</router-link></p>
    </section>


    <section
        class="flex flex-wrap justify-center align-center mx-4 px-4 py-8 shadow-md border border-indigo-500 max-w-140 mx-auto">
        <p class="font-bold text-indigo-700 basis-full">Ofertas publicadas</p>
        <FeedList :posts="posts" :user="user" ref="feedList" @post-submitted="publishComment" />
    </section>

</template>